#ifndef SECURECHAT_H
#define SECURECHAT_H

#include <stddef.h>
#include <stdint.h>

#define SC_KEY_LEN 32
#define SC_NONCE_LEN 12
#define SC_TAG_LEN 16
#define SC_SIGNATURE_LEN 64

int sc_x25519_keypair(uint8_t public_key[SC_KEY_LEN], uint8_t private_key[SC_KEY_LEN]);
int sc_x25519_shared_secret(const uint8_t private_key[SC_KEY_LEN],
                            const uint8_t peer_public_key[SC_KEY_LEN],
                            uint8_t shared_secret[SC_KEY_LEN]);
int sc_hkdf_sha256(const uint8_t *secret, size_t secret_len,
                   const uint8_t *salt, size_t salt_len,
                   const uint8_t *info, size_t info_len,
                   uint8_t key[SC_KEY_LEN]);
int sc_aes256gcm_encrypt(const uint8_t key[SC_KEY_LEN],
                         const uint8_t nonce[SC_NONCE_LEN],
                         const uint8_t *plaintext, size_t plaintext_len,
                         uint8_t *ciphertext, uint8_t tag[SC_TAG_LEN]);
int sc_aes256gcm_decrypt(const uint8_t key[SC_KEY_LEN],
                         const uint8_t nonce[SC_NONCE_LEN],
                         const uint8_t *ciphertext, size_t ciphertext_len,
                         const uint8_t tag[SC_TAG_LEN], uint8_t *plaintext);
int sc_ed25519_keypair(uint8_t public_key[SC_KEY_LEN], uint8_t private_key[SC_KEY_LEN]);
int sc_ed25519_sign(const uint8_t private_key[SC_KEY_LEN],
                    const uint8_t *message, size_t message_len,
                    uint8_t signature[SC_SIGNATURE_LEN]);
int sc_ed25519_verify(const uint8_t public_key[SC_KEY_LEN],
                      const uint8_t *message, size_t message_len,
                      const uint8_t signature[SC_SIGNATURE_LEN]);

#endif
