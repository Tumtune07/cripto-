# SecureChat E2EE (C)

Educational end-to-end encryption prototype written in C using OpenSSL 3.x.

## Features

- X25519 key agreement.
- HKDF-SHA256 key derivation.
- AES-256-GCM authenticated encryption.
- Ed25519 digital signatures.
- Tests for shared-secret agreement, encryption/decryption, tampering, and signature validation.

> **Security scope:** This is an educational portfolio project, not a production-ready messenger. It does not implement a network protocol, identity verification, replay protection, secure key storage, or an audited messaging protocol. Do not use it to protect real sensitive communications.

## Requirements

- C compiler (GCC or Clang)
- Make
- OpenSSL development headers and libraries (OpenSSL 3.x recommended)

## Build and run

```sh
make
./securechat
```

Run tests:

```sh
make test
```

Clean generated binaries:

```sh
make clean
```

## Layout

```text
.
├── include/securechat.h
├── src/crypto.c
├── src/main.c
├── tests/test_crypto.c
├── Makefile
├── .gitignore
├── LICENSE
└── README.md
```

## Design

1. Two parties generate X25519 key pairs and derive the same shared secret.
2. HKDF-SHA256 derives a 256-bit key from that secret and a context string.
3. AES-256-GCM encrypts and authenticates a message.
4. Ed25519 signs the original message; the recipient verifies it with the sender's public key.

**Important:** AES-GCM nonces must never repeat with the same key. The demo uses a fixed nonce only for its single local demonstration; a real application must generate a unique nonce for every encryption under a given key. Public keys must be authenticated through a trusted mechanism in a real application. Encryption alone does not prove who owns a public key.

## License

MIT. See `LICENSE`.
