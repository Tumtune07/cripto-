#include "securechat.h"

#include <limits.h>
#include <openssl/evp.h>
#include <openssl/kdf.h>
#include <openssl/params.h>
#include <string.h>

static int size_fits_int(size_t n) { return n <= (size_t)INT_MAX; }

int sc_x25519_keypair(uint8_t public_key[SC_KEY_LEN], uint8_t private_key[SC_KEY_LEN]) {
    int ok = 0;
    size_t pub_len = SC_KEY_LEN, priv_len = SC_KEY_LEN;
    EVP_PKEY_CTX *ctx = EVP_PKEY_CTX_new_id(EVP_PKEY_X25519, NULL);
    EVP_PKEY *pkey = NULL;
    if (!ctx) goto done;
    if (EVP_PKEY_keygen_init(ctx) <= 0 || EVP_PKEY_keygen(ctx, &pkey) <= 0) goto done;
    if (EVP_PKEY_get_raw_public_key(pkey, public_key, &pub_len) <= 0 ||
        EVP_PKEY_get_raw_private_key(pkey, private_key, &priv_len) <= 0) goto done;
    ok = (pub_len == SC_KEY_LEN && priv_len == SC_KEY_LEN);
done:
    EVP_PKEY_free(pkey);
    EVP_PKEY_CTX_free(ctx);
    return ok;
}

int sc_x25519_shared_secret(const uint8_t private_key[SC_KEY_LEN],
                            const uint8_t peer_public_key[SC_KEY_LEN],
                            uint8_t shared_secret[SC_KEY_LEN]) {
    int ok = 0;
    size_t out_len = SC_KEY_LEN;
    EVP_PKEY *local = EVP_PKEY_new_raw_private_key(EVP_PKEY_X25519, NULL, private_key, SC_KEY_LEN);
    EVP_PKEY *peer = EVP_PKEY_new_raw_public_key(EVP_PKEY_X25519, NULL, peer_public_key, SC_KEY_LEN);
    EVP_PKEY_CTX *ctx = NULL;
    if (!local || !peer) goto done;
    ctx = EVP_PKEY_CTX_new(local, NULL);
    if (!ctx || EVP_PKEY_derive_init(ctx) <= 0 ||
        EVP_PKEY_derive_set_peer(ctx, peer) <= 0 ||
        EVP_PKEY_derive(ctx, shared_secret, &out_len) <= 0) goto done;
    ok = (out_len == SC_KEY_LEN);
done:
    EVP_PKEY_CTX_free(ctx);
    EVP_PKEY_free(local);
    EVP_PKEY_free(peer);
    return ok;
}

int sc_hkdf_sha256(const uint8_t *secret, size_t secret_len,
                   const uint8_t *salt, size_t salt_len,
                   const uint8_t *info, size_t info_len,
                   uint8_t key[SC_KEY_LEN]) {
    int ok = 0;
    EVP_PKEY_CTX *ctx = EVP_PKEY_CTX_new_id(EVP_PKEY_HKDF, NULL);
    size_t out_len = SC_KEY_LEN;
    if (!ctx || !secret || secret_len == 0 ||
        (salt_len && !salt) || (info_len && !info)) goto done;
    if (EVP_PKEY_derive_init(ctx) <= 0 ||
        EVP_PKEY_CTX_set_hkdf_md(ctx, EVP_sha256()) <= 0 ||
        EVP_PKEY_CTX_set1_hkdf_salt(ctx, salt, (int)salt_len) <= 0 ||
        EVP_PKEY_CTX_set1_hkdf_key(ctx, secret, (int)secret_len) <= 0 ||
        (info_len && EVP_PKEY_CTX_add1_hkdf_info(ctx, info, (int)info_len) <= 0) ||
        EVP_PKEY_derive(ctx, key, &out_len) <= 0) goto done;
    ok = out_len == SC_KEY_LEN;
done:
    EVP_PKEY_CTX_free(ctx);
    return ok;
}

int sc_aes256gcm_encrypt(const uint8_t key[SC_KEY_LEN],
                         const uint8_t nonce[SC_NONCE_LEN],
                         const uint8_t *plaintext, size_t plaintext_len,
                         uint8_t *ciphertext, uint8_t tag[SC_TAG_LEN]) {
    int ok = 0, out_len = 0, final_len = 0;
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx || !key || !nonce || (plaintext_len && (!plaintext || !ciphertext)) ||
        !tag || !size_fits_int(plaintext_len)) goto done;
    if (EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL) <= 0 ||
        EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, SC_NONCE_LEN, NULL) <= 0 ||
        EVP_EncryptInit_ex(ctx, NULL, NULL, key, nonce) <= 0) goto done;
    if (plaintext_len && EVP_EncryptUpdate(ctx, ciphertext, &out_len, plaintext, (int)plaintext_len) <= 0) goto done;
    if (EVP_EncryptFinal_ex(ctx, ciphertext ? ciphertext + out_len : NULL, &final_len) <= 0 ||
        EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, SC_TAG_LEN, tag) <= 0) goto done;
    ok = 1;
done:
    EVP_CIPHER_CTX_free(ctx);
    return ok;
}

int sc_aes256gcm_decrypt(const uint8_t key[SC_KEY_LEN],
                         const uint8_t nonce[SC_NONCE_LEN],
                         const uint8_t *ciphertext, size_t ciphertext_len,
                         const uint8_t tag[SC_TAG_LEN], uint8_t *plaintext) {
    int ok = 0, out_len = 0, final_len = 0;
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx || !key || !nonce || (ciphertext_len && (!ciphertext || !plaintext)) ||
        !tag || !size_fits_int(ciphertext_len)) goto done;
    if (EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL) <= 0 ||
        EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, SC_NONCE_LEN, NULL) <= 0 ||
        EVP_DecryptInit_ex(ctx, NULL, NULL, key, nonce) <= 0) goto done;
    if (ciphertext_len && EVP_DecryptUpdate(ctx, plaintext, &out_len, ciphertext, (int)ciphertext_len) <= 0) goto done;
    if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, SC_TAG_LEN, (void *)tag) <= 0) goto done;
    ok = EVP_DecryptFinal_ex(ctx, plaintext ? plaintext + out_len : NULL, &final_len) > 0;
    if (!ok && plaintext && ciphertext_len) OPENSSL_cleanse(plaintext, ciphertext_len);
done:
    EVP_CIPHER_CTX_free(ctx);
    return ok;
}

int sc_ed25519_keypair(uint8_t public_key[SC_KEY_LEN], uint8_t private_key[SC_KEY_LEN]) {
    int ok = 0;
    size_t pub_len = SC_KEY_LEN, priv_len = SC_KEY_LEN;
    EVP_PKEY_CTX *ctx = EVP_PKEY_CTX_new_id(EVP_PKEY_ED25519, NULL);
    EVP_PKEY *pkey = NULL;
    if (!ctx || EVP_PKEY_keygen_init(ctx) <= 0 || EVP_PKEY_keygen(ctx, &pkey) <= 0) goto done;
    if (EVP_PKEY_get_raw_public_key(pkey, public_key, &pub_len) <= 0 ||
        EVP_PKEY_get_raw_private_key(pkey, private_key, &priv_len) <= 0) goto done;
    ok = pub_len == SC_KEY_LEN && priv_len == SC_KEY_LEN;
done:
    EVP_PKEY_free(pkey);
    EVP_PKEY_CTX_free(ctx);
    return ok;
}

int sc_ed25519_sign(const uint8_t private_key[SC_KEY_LEN],
                    const uint8_t *message, size_t message_len,
                    uint8_t signature[SC_SIGNATURE_LEN]) {
    int ok = 0;
    size_t sig_len = SC_SIGNATURE_LEN;
    EVP_PKEY *pkey = NULL;
    EVP_MD_CTX *ctx = NULL;
    if (!private_key || (message_len && !message) || !signature) goto done;
    pkey = EVP_PKEY_new_raw_private_key(EVP_PKEY_ED25519, NULL, private_key, SC_KEY_LEN);
    ctx = EVP_MD_CTX_new();
    if (!pkey || !ctx || EVP_DigestSignInit(ctx, NULL, NULL, NULL, pkey) <= 0 ||
        EVP_DigestSign(ctx, signature, &sig_len, message, message_len) <= 0) goto done;
    ok = sig_len == SC_SIGNATURE_LEN;
done:
    EVP_MD_CTX_free(ctx);
    EVP_PKEY_free(pkey);
    return ok;
}

int sc_ed25519_verify(const uint8_t public_key[SC_KEY_LEN],
                      const uint8_t *message, size_t message_len,
                      const uint8_t signature[SC_SIGNATURE_LEN]) {
    int ok = 0;
    EVP_PKEY *pkey = NULL;
    EVP_MD_CTX *ctx = NULL;
    if (!public_key || (message_len && !message) || !signature) goto done;
    pkey = EVP_PKEY_new_raw_public_key(EVP_PKEY_ED25519, NULL, public_key, SC_KEY_LEN);
    ctx = EVP_MD_CTX_new();
    if (!pkey || !ctx || EVP_DigestVerifyInit(ctx, NULL, NULL, NULL, pkey) <= 0) goto done;
    ok = EVP_DigestVerify(ctx, signature, SC_SIGNATURE_LEN, message, message_len) == 1;
done:
    EVP_MD_CTX_free(ctx);
    EVP_PKEY_free(pkey);
    return ok;
}
