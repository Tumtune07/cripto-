#include "securechat.h"

#include <stdio.h>
#include <string.h>

int main(void) {
    uint8_t alice_pub[SC_KEY_LEN], alice_priv[SC_KEY_LEN];
    uint8_t bob_pub[SC_KEY_LEN], bob_priv[SC_KEY_LEN];
    uint8_t alice_secret[SC_KEY_LEN], bob_secret[SC_KEY_LEN];
    uint8_t key[SC_KEY_LEN], nonce[SC_NONCE_LEN] = {0};
    uint8_t ciphertext[256], tag[SC_TAG_LEN], plaintext[256];
    uint8_t sign_pub[SC_KEY_LEN], sign_priv[SC_KEY_LEN], signature[SC_SIGNATURE_LEN];
    const uint8_t message[] = "Hello from SecureChat!";
    size_t message_len = sizeof(message) - 1;

    if (!sc_x25519_keypair(alice_pub, alice_priv) ||
        !sc_x25519_keypair(bob_pub, bob_priv) ||
        !sc_x25519_shared_secret(alice_priv, bob_pub, alice_secret) ||
        !sc_x25519_shared_secret(bob_priv, alice_pub, bob_secret) ||
        memcmp(alice_secret, bob_secret, SC_KEY_LEN) != 0) {
        fprintf(stderr, "Key agreement failed\n");
        return 1;
    }
    if (!sc_hkdf_sha256(alice_secret, SC_KEY_LEN, NULL, 0,
                        (const uint8_t *)"SecureChat demo v1", 18, key)) {
        fprintf(stderr, "Key derivation failed\n");
        return 1;
    }
    if (!sc_aes256gcm_encrypt(key, nonce, message, message_len, ciphertext, tag)) {
        fprintf(stderr, "Encryption failed\n");
        return 1;
    }
    if (!sc_aes256gcm_decrypt(key, nonce, ciphertext, message_len, tag, plaintext)) {
        fprintf(stderr, "Decryption/authentication failed\n");
        return 1;
    }
    plaintext[message_len] = '\0';

    if (!sc_ed25519_keypair(sign_pub, sign_priv) ||
        !sc_ed25519_sign(sign_priv, message, message_len, signature) ||
        !sc_ed25519_verify(sign_pub, message, message_len, signature)) {
        fprintf(stderr, "Signature check failed\n");
        return 1;
    }

    printf("SecureChat E2EE crypto demo\n");
    printf("X25519 key agreement: OK\n");
    printf("HKDF-SHA256 key derivation: OK\n");
    printf("AES-256-GCM encrypt/decrypt: OK\n");
    printf("Ed25519 signature verification: OK\n");
    printf("Decrypted message: %s\n", (char *)plaintext);
    return 0;
}
