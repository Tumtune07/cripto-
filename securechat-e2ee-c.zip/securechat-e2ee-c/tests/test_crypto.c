#include "securechat.h"

#include <stdio.h>
#include <string.h>

#define CHECK(expr) do { if (!(expr)) { \
    fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #expr); return 1; \
} } while (0)

int main(void) {
    uint8_t ap[SC_KEY_LEN], as[SC_KEY_LEN], bp[SC_KEY_LEN], bs[SC_KEY_LEN];
    uint8_t sa[SC_KEY_LEN], sb[SC_KEY_LEN], key[SC_KEY_LEN];
    uint8_t nonce[SC_NONCE_LEN] = {1,2,3,4,5,6,7,8,9,10,11,12};
    uint8_t cipher[64], recovered[64], tag[SC_TAG_LEN];
    uint8_t sp[SC_KEY_LEN], ss[SC_KEY_LEN], sig[SC_SIGNATURE_LEN];
    const uint8_t msg[] = "test message";
    const size_t n = sizeof(msg) - 1;

    CHECK(sc_x25519_keypair(ap, as));
    CHECK(sc_x25519_keypair(bp, bs));
    CHECK(sc_x25519_shared_secret(as, bp, sa));
    CHECK(sc_x25519_shared_secret(bs, ap, sb));
    CHECK(memcmp(sa, sb, SC_KEY_LEN) == 0);
    CHECK(sc_hkdf_sha256(sa, SC_KEY_LEN, NULL, 0,
                         (const uint8_t *)"test context", 12, key));

    CHECK(sc_aes256gcm_encrypt(key, nonce, msg, n, cipher, tag));
    CHECK(sc_aes256gcm_decrypt(key, nonce, cipher, n, tag, recovered));
    CHECK(memcmp(msg, recovered, n) == 0);

    tag[0] ^= 1;
    CHECK(!sc_aes256gcm_decrypt(key, nonce, cipher, n, tag, recovered));
    tag[0] ^= 1;

    CHECK(sc_ed25519_keypair(sp, ss));
    CHECK(sc_ed25519_sign(ss, msg, n, sig));
    CHECK(sc_ed25519_verify(sp, msg, n, sig));
    CHECK(!sc_ed25519_verify(sp, (const uint8_t *)"tampered", 8, sig));

    puts("All SecureChat tests passed.");
    return 0;
}
